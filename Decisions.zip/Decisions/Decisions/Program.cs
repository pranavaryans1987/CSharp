﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Decisions
{
    class Program
    {
        static void Main(string[] args)
        {
            /* string result="",grade="";
            double per;
            Console.Write("Enter Student Name : ");
            string nm = Console.ReadLine();

            Console.Write("Enter Marks For Subject1 : ");
            int sub1 = int.Parse(Console.ReadLine());

            Console.Write("Enter Marks For Subject2 : ");
            int sub2 = int.Parse(Console.ReadLine());

            Console.Write("Enter Marks For Subject3 : ");
            int sub3 = int.Parse(Console.ReadLine());

            Console.Write("Enter Marks For Subject4 : ");
            int sub4 = int.Parse(Console.ReadLine());

            int total = sub1 + sub2 + sub3 + sub4;

            if (sub1 >= 40 && sub2 >= 40 && sub3 >= 40 && sub4 >= 40)
            {
                result = "Pass";
                per = total / 4;

                if (per >= 40 && per <= 49.99)
                {
                    grade = "Pass";
                }
                else if (per >= 50 && per <= 59.99)
                {
                    grade = "Second";
                }
                else if (per >= 60 && per <= 69.99)
                {
                    grade = "First";
                }
                else if (per >= 70)
                {
                    grade = "Dist.";
                }
            }
            else
            {
                result = "Fail";
                per = 0.0;
                grade = "Fail";
            }

            Console.WriteLine();
            Console.WriteLine("Hello " + nm + " Your Result is As Follows");
            Console.WriteLine("Total Marks Obtained : " + total);
            Console.WriteLine("Your Result is : " + result);
            Console.WriteLine("Your Percentage is : " + per);
            Console.WriteLine("Your Grade is : " + grade);*/


            //Switch Case
            Console.Write("Enter Any Number Between 1 to 7 :");
            int d = int.Parse(Console.ReadLine());

            switch (d)
            {
                case 1:
                    Console.WriteLine("Monday");
                    break;
                case 2:
                    Console.WriteLine("Tuesday");
                    break;
                case 3:
                    Console.WriteLine("Wednesday");
                    break;
                case 4:
                    Console.WriteLine("Thursday");
                    break;
                case 5:
                    Console.WriteLine("Friday");
                    break;
                case 6:
                    Console.WriteLine("Saturday");
                    break;
                case 7:
                    Console.WriteLine("Sunday");
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                    break;
            }

            Console.Read();
        }
    }
}
