﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pointers
{
    class Program
    {
        static void Main(string[] args)
        {
            unsafe
            {
                int age = 32;
                int* age_ptr;
                Console.WriteLine("age = {0}", age);
                Console.Read();
            }
        }
    }
}
