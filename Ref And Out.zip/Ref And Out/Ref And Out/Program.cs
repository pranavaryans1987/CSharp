﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ref_And_Out
{
    class Program
    {
        public static void RefParamMethod(ref int num1, ref int num2)
        {
            num1 = 50;
            num2 = 140;
        }

        public static void OutParamMethod(out int num3, out string str1)
        {
            num3 = 20;
            str1 = "Hi I am out";
        }
        static void Main(string[] args)
        {
            int num3;
            string str1;
            int n1 = 0;
            int n2 = 0;
            RefParamMethod(ref n1, ref n2);
            OutParamMethod(out num3, out str1);
            Console.WriteLine("n1 = " + n1);
            Console.WriteLine("n2 = " + n2);
            Console.WriteLine("num3 = " + num3);
            Console.WriteLine("str1 = " + str1);
            Console.Read();
        }
    }
}
