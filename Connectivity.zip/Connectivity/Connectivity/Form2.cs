﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Connectivity
{
    public partial class Form2 : Form
    {
        SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\SYIT.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            loaddata();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "insert into login values('" + textBox1.Text + "','" + textBox2.Text + "')";
            SqlDataAdapter da = new SqlDataAdapter(sql,cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            MessageBox.Show("Record Inserted!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
            loaddata();
            clear();
        }

        private void loaddata()
        {
            string sql = "select * from login";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void clear()
        {
            textBox1.Text = textBox2.Text = "";
            textBox1.Focus();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Delete)
            {
                if (dataGridView1.Rows.Count >= 1)
                {
                        DialogResult dr = MessageBox.Show("Do you want to Delete?", "DELETE", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                        switch (dr)
                        {
                                case DialogResult.Yes:
                                SqlDataAdapter da = new SqlDataAdapter("delete from login where username='" + dataGridView1.SelectedCells[0].Value.ToString() + "'", cn);
                                DataTable dt = new DataTable();
                                da.Fill(dt);
                                loaddata();
                                break;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot Delete Record!");
                    }
                }

            if (keyData == Keys.U)
            {
                string sql = "select * from login where username='" + dataGridView1.SelectedCells[0].Value.ToString() + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql,cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                textBox1.Text = dt.Rows[0][0].ToString();
                textBox2.Text = dt.Rows[0][1].ToString();
            }
                return base.ProcessCmdKey(ref msg, keyData);
            }

        private void button3_Click(object sender, EventArgs e)
        {
            string value = dataGridView1.SelectedCells[0].Value.ToString();
            string sql = "update login set username='" + textBox2.Text + "',password='" + textBox2.Text + "' where username='" + value + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql,cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            MessageBox.Show("Record Updated!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
            loaddata();
            clear();
        }
    }
}
