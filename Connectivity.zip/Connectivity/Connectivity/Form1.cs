﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Connectivity
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\SYIT.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
            //CONNECTED ARCH.
            //cn.Open();
            //SqlCommand cmd = new SqlCommand(sql, cn);
            //SqlDataReader dr = null;
            //dr = cmd.ExecuteReader();
            string sql = "select * from login where username='" + textBox1.Text + "' and password='" + textBox2.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql,cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count >=1)
            {
                Form2 F2 = new Form2();
                F2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid!", "Databse", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                clear();
            }
        }

        private void clear()
        {
            textBox1.Text = textBox2.Text = "";
            textBox1.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}
