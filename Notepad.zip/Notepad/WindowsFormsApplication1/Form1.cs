﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            if (richTextBox1.Text != "")
            {
                this.Text = "Notepad *";
            }
            else
            {
                this.Text = "Notepad";
            }
        }

        private void backColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog C = new ColorDialog();
            C.ShowDialog();
            richTextBox1.BackColor = C.Color;
        }

        private void fontColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog C = new ColorDialog();
            C.ShowDialog();
            richTextBox1.ForeColor = C.Color;
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog F = new FontDialog();
            F.ShowDialog();
            richTextBox1.Font = F.Font;
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog S = new SaveFileDialog();
            S.ShowDialog();
            richTextBox1.SaveFile(S.FileName);
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog O = new OpenFileDialog();
            O.ShowDialog();
            richTextBox1.LoadFile(O.FileName);
        }
    }
}
