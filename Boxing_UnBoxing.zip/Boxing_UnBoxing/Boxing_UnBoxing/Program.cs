﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Boxing_UnBoxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5;
            Object obj = a; // Boxing

            int b = (int)obj; //Unboxing

            Console.Write(b);
            Console.Read();
        }
    }
}
