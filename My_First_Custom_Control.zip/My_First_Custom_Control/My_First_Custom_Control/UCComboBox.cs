﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace My_First_Custom_Control
{
    public partial class UCComboBox : UserControl
    {
        public UCComboBox()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "BCA")
            {
                MessageBox.Show("BCA is selected!");
            }
            else if (comboBox1.Text == "BSCIT")
            {
                MessageBox.Show("BSCIT is selected!");
            }
            else if (comboBox1.Text == "MCA")
            {
                MessageBox.Show("MCA is selected!");
            }
            else if (comboBox1.Text == "MSCIT")
            {
                MessageBox.Show("MSCIT is selected!");
            }
            else
            {
                MessageBox.Show("None Selected!");
            }
        }
    }
}
