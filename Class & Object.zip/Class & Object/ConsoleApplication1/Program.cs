﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        class Printdata
        {
            void print(int i)
            {
                Console.WriteLine("Printing int: {0}", i);
            }
            void print(double f)
            {
                Console.WriteLine("Printing float: {0}", f);
            }
            void print(string s)
            {
                Console.WriteLine("Printing string: {0}", s);
            }
            static void Main(string[] args)
            {
                Printdata p = new Printdata();
                p.print(5);
                p.print(500.263);
                p.print("Hello C++");
                Console.ReadKey();
            }
        }
    }
}

