﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DIV_A
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUnm.Text != "" && txtPwd.Text != "")
            {
                string sql = "select * from admin_login where unm='" + txtUnm.Text + "' and pwd='" + txtPwd.Text + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 1)
                {
                    Home H = new Home();
                    H.Show();
                    this.Hide();
                }
                else
                {
                    clr();
                }
            }
            else
            {
                clr();
            }
        }

        private void clr()
        {
            MessageBox.Show("Enter!", "App", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtUnm.Text = txtPwd.Text = string.Empty;
            txtUnm.Focus();
        }
    }
}
